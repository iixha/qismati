import 'package:flutter/material.dart';
import 'package:qismati/qismati_app.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const QismatiApp());
}
